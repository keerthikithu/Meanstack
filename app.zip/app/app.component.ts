import { transition ,trigger,state,style,animate,keyframes, useAnimation,query,animateChild,group} from '@angular/animations';
import { Component } from '@angular/core';
import { changeDivDimension,fadeInOut,newAnimation1,slide} from './animations';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations:[trigger('animation1',[
                    transition(':enter',[group([animate(1000,style({backgroundColor:'red'})),
                                                animate(2000,style({transform:'translateY(20px)'}))])])]),

    trigger('newAnimation',[
              transition(':enter',[style({opacity:0}),animate(2000)]),
              transition(':leave',useAnimation(newAnimation1))
  ]),
    changeDivDimension ,slide]
})
export class AppComponent {
  items:any[]=['hai','hello'];

  insertItem(input:HTMLInputElement){
    this.items.splice(0,0,input.value);
    input.value='';
  }
  removeItem(item){
    let index=this.items.indexOf(item);
    this.items.splice(index,1);

  }
  currentState='initial';
  changeState(){
        this.currentState=this.currentState==='initial'?'final':'initial';
  }
  animationStart($event){console.log($event);}
  animationDone($event){console.log($event);}

}
