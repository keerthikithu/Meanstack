import { transition ,trigger,state,style,animate,keyframes, animation, useAnimation} from '@angular/animations';
export let newAnimation1=animation(animate('1000ms cubic-bezier(.2,.79,.92,.58)',style({transform:'translateX(100%)'})))
export let changeDivDimension=trigger('changeDivDimension',
[state('initial',style({backgroundColor:'blue',width:'100px',height:'200px'})),
state('final',style({backgroundColor:'pink',width:'200px',height:'400px'})),
transition('initial=>final',animate(1000)),
transition('final=>initial',animate(2000,keyframes([style({backgroundColor:'red'}),
                                                    style({backgroundColor:'orange'}),
                                                    style({backgroundColor:'pink'}),
                                                    style({backgroundColor:'black'})])))])
export let fadeInOut=trigger('fadeInOut',[state('void',style({opacity:0})),transition('void<=>*',animate(1000))])

export let slide=trigger('slide',[transition(':enter',[style({transform:'translateX(-30px)'}),animate('500ms ease-in')]),
                                  transition(':leave',useAnimation(newAnimation1))])
