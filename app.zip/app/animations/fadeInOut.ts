import { transition ,trigger,state,style,animate,keyframes} from '@angular/animations';
